#!/usr/bin/env python

from distutils.core import setup

setup(name='read_dat',
      version='1.0',
      description='read_dat',
      author='Miles Kidson',
      author_email='kdsmil001@myuct.ac.za',
      py_modules=['read_dat', 'event']
     )